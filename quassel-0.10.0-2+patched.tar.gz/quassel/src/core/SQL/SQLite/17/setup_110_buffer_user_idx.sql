CREATE INDEX buffer_user_idx ON buffer(userid)
