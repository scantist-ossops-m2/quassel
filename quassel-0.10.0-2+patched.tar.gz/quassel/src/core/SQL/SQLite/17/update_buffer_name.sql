UPDATE buffer
SET buffername = :buffername, buffercname = :buffercname
WHERE bufferid = :bufferid AND userid = :userid
