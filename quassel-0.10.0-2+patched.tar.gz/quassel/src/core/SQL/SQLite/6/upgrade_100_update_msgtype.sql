UPDATE backlog SET type = 64 WHERE type = 6
