INSERT INTO identity_nick (identityid, nick)
VALUES (:identityid, :nick)
