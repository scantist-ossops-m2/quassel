DELETE FROM buffer
WHERE userid = :userid AND bufferid = :bufferid
