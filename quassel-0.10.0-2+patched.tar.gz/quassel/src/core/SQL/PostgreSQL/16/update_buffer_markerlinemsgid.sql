UPDATE buffer
SET markerlinemsgid = :markerlinemsgid
WHERE userid = :userid AND bufferid = :bufferid
