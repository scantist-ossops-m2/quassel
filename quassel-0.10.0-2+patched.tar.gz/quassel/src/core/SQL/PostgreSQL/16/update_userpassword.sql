UPDATE quasseluser
SET password = :password
WHERE userid = :userid
