SELECT usermode
FROM network
WHERE userid = :userid AND networkid = :networkid