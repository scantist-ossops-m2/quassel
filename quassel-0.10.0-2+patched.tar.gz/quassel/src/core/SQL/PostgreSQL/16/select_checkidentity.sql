SELECT count(*)
FROM identity
WHERE identityid = :identityid AND userid = :userid
