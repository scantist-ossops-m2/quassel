SELECT min(userid)
FROM quasseluser
