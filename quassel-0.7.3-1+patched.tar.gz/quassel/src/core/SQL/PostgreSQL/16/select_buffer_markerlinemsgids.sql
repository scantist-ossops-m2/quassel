SELECT bufferid, markerlinemsgid
FROM buffer
WHERE userid = :userid
