UPDATE quasseluser
SET username = :username
WHERE userid = :userid
