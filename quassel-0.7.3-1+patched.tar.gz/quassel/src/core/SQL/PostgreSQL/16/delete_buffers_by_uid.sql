DELETE FROM buffer
WHERE userid = :userid
