UPDATE backlog SET flags = flags & 1
