UPDATE backlog SET type = 256 WHERE type = 8
