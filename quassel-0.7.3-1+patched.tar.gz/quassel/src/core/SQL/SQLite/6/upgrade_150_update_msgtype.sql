UPDATE backlog SET type = 2 WHERE type = 1
