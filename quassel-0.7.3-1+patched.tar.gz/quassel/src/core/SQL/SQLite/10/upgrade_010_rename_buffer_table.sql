ALTER TABLE buffer RENAME TO buffer_old
