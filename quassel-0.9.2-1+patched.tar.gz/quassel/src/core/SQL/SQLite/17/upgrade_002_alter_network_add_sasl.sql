ALTER TABLE network
ADD COLUMN
saslpassword TEXT
