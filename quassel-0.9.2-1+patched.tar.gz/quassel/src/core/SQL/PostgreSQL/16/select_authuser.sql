SELECT userid
FROM quasseluser
WHERE username = :username AND password = :password
