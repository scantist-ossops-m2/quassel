DELETE FROM backlog
WHERE bufferid = :bufferid
