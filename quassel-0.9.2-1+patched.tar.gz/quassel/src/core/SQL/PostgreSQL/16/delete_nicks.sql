DELETE FROM identity_nick
WHERE identityid = :identityid;
