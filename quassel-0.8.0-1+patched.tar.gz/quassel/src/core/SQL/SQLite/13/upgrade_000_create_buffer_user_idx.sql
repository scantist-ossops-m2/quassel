CREATE INDEX IF NOT EXISTS buffer_user_idx ON buffer(userid)
