INSERT INTO buffer (bufferid, userid, groupid, networkid, buffername, buffercname, buffertype, lastseenmsgid, markerlinemsgid, key, joined)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
