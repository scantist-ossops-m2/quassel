DELETE FROM quasseluser
WHERE userid = :userid
