INSERT INTO coreinfo (key, value) VALUES ('schemaversion', '1')
