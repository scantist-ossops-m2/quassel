UPDATE coreinfo
SET value='3'
WHERE key = 'schemaversion'
