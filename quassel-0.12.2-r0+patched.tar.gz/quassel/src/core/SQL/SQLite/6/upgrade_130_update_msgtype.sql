UPDATE backlog SET type = 8 WHERE type = 3
