UPDATE buffer
SET buffertype = 4
WHERE buffertype = 0
