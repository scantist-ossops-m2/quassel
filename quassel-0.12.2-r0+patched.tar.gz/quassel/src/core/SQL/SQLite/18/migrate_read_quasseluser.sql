SELECT userid, username, password
FROM quasseluser
