CREATE UNIQUE INDEX buffer_idx 
       ON buffer(userid, networkid, buffername)
