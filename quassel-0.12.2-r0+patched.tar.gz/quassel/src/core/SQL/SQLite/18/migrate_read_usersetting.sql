SELECT userid, settingname, settingvalue
FROM user_setting

