ALTER TABLE network RENAME TO networkold
