ALTER TABLE network
ADD COLUMN
saslaccount TEXT
