INSERT INTO quasseluser (username, password, hashversion)
VALUES (:username, :password, :hashversion)
RETURNING userid
