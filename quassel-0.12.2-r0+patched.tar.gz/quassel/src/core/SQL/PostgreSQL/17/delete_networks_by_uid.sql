DELETE FROM network
WHERE userid = :userid
