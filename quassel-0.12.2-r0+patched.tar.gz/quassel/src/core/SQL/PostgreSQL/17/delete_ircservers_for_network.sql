DELETE FROM ircserver
WHERE networkid = :networkid
