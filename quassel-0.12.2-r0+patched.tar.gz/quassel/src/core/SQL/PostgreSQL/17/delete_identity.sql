DELETE FROM identity
WHERE identityid = :identityid AND userid = :userid
