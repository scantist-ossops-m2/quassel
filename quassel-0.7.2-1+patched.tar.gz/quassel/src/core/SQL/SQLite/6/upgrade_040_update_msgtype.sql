UPDATE backlog SET type = 4069 WHERE type = 12
