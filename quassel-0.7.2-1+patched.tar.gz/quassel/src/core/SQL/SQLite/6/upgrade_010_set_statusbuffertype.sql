UPDATE buffer
SET buffertype = 1
WHERE buffercname = ''
