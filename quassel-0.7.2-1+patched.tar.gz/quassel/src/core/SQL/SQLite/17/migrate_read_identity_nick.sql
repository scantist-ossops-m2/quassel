SELECT nickid, identityid, nick
FROM identity_nick
