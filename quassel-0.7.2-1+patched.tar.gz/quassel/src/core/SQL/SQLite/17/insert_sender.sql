INSERT INTO sender (sender)
VALUES (:sender)