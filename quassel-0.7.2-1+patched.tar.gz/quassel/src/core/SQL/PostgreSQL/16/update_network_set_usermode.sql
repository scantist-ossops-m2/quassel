UPDATE network
SET usermode = :usermode
WHERE userid = :userid AND networkid = :networkid