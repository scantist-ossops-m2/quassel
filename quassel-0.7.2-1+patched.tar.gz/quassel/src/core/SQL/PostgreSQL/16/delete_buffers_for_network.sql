DELETE FROM buffer
WHERE networkid = :networkid
