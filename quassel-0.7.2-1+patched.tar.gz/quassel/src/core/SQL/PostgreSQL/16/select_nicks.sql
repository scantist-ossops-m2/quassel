SELECT nick
FROM identity_nick
WHERE identityid = :identityid
ORDER BY nickid ASC
