ALTER TABLE buffer
ADD COLUMN markerlinemsgid integer NOT NULL DEFAULT 0
