SELECT networkname
FROM network
WHERE userid = :userid AND networkid = :networkid
