UPDATE backlog SET type = 32 WHERE type = 5
