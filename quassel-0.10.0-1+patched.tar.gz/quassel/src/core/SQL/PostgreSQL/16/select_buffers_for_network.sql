SELECT bufferid
FROM buffer
WHERE networkid = :networkid and userid = :userid

