ALTER SEQUENCE backlog_messageid_seq CACHE 100
