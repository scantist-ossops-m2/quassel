INSERT INTO quasseluser (username, password)
VALUES (:username, :password)
RETURNING userid
