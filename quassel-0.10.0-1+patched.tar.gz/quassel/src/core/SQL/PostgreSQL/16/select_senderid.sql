SELECT senderid
FROM sender
WHERE sender = $1
