UPDATE backlog SET type = 16 WHERE type = 4
