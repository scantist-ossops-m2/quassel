UPDATE buffer
SET key = :key
WHERE userid = :userid AND networkid = :networkid AND buffercname = :buffercname AND buffertype = 2
