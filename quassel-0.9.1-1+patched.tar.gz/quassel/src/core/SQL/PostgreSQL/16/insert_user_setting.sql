INSERT INTO user_setting (userid, settingname, settingvalue)
VALUES (:userid, :settingname, :settingvalue)
