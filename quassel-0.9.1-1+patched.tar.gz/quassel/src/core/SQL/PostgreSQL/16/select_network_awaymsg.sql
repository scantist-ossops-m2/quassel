SELECT awaymessage
FROM network
WHERE userid = :userid AND networkid = :networkid
