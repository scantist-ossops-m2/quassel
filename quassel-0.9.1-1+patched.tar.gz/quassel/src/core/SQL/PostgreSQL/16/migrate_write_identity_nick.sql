INSERT INTO identity_nick (nickid, identityid, nick)
VALUES (?, ?, ?)
