UPDATE buffer
SET joined = 1
WHERE buffertype = 2
