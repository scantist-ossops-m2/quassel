DROP TABLE buffer_old
