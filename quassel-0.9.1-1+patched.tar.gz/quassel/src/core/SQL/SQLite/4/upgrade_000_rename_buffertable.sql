ALTER TABLE buffer RENAME TO bufferold
