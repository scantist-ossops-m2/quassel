DELETE FROM network
WHERE networkid = :networkid AND userid = :userid

