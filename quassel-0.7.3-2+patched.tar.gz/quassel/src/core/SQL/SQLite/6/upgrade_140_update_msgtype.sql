UPDATE backlog SET type = 4 WHERE type = 2
