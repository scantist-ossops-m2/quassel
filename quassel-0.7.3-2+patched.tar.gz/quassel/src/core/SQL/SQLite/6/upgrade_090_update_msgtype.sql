UPDATE backlog SET type = 128 WHERE type = 7
