ALTER TABLE ircserver RENAME TO ircserverold
