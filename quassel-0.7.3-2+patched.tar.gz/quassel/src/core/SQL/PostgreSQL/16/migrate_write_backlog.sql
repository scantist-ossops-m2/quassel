INSERT INTO backlog (messageid, time, bufferid, type, flags, senderid, message)
VALUES (?, ?, ?, ?, ?, ?, ?)
