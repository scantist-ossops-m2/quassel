UPDATE backlog SET type = 1 WHERE type = 0
