SELECT bufferid, lastseenmsgid
FROM buffer
WHERE userid = :userid
