CREATE TABLE coreinfo (
       key TEXT NOT NULL PRIMARY KEY,
       value TEXT
)
