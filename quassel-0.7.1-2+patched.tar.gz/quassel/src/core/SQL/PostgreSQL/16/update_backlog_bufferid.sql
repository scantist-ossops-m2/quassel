UPDATE backlog
SET bufferid = :newbufferid
WHERE bufferid = :oldbufferid
