UPDATE backlog SET type = 1024 WHERE type = 10
