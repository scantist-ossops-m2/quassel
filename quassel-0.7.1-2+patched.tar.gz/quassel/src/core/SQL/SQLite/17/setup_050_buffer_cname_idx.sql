CREATE UNIQUE INDEX buffer_cname_idx 
       ON buffer(userid, networkid, buffercname)
