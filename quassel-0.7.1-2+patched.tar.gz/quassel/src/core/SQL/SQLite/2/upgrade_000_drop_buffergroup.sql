DROP TABLE buffergroup
