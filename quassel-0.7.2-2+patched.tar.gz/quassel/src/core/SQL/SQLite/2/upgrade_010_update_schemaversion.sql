UPDATE coreinfo
SET value='2'
WHERE key = 'schemaversion'
