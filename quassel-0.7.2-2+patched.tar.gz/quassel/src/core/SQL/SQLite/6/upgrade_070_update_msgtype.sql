UPDATE backlog SET type = 512 WHERE type = 9
