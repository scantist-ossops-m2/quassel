UPDATE backlog SET type = 2048 WHERE type = 11
