INSERT INTO quasseluser (userid, username, password)
VALUES (?, ?, ?)
